# Prediction-using-Supervised-ML-The-Sparks-Foundation
#  GRIP - The Spark Foundation 
**Data Science and Business Analytics Intern** 
# Author: Ambareen Azam 
**Task 1: Prediction using Supervised ML** 
● Predict the percentage of an student based on the no. of study hours.
● This is a simple linear regression task as it involves just 2 variables.
